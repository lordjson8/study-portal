# 06 — Feature modules, react-hook-form + zod

## What is a "feature module"?

A self-contained folder under `portals/main-portal/features/<name>/`
that owns:

- its own pages (routes),
- its own components (only used inside the feature),
- its own service file (API calls),
- its own types if the contracts file isn't enough.

The feature does NOT reach into another feature's internals. If two
features share something, that something moves up to
`components/shared/` or `services/`. This is the "screaming
architecture" idea: opening `features/souscriptions/` should tell you
what the feature does without spelunking.

## What we build for Souscriptions

| File | What it does |
|---|---|
| `api.ts` | Three functions: `listTickets`, `getTicket`, `createTicket`. Each calls `apiClient` with the right verb/URL. The mock fallback in the interceptor handles the absent backend transparently. |
| `pages/SouscriptionsListPage.tsx` | Table of tickets, a "Créer une demande" button gated by `ticket:create`. Loading + empty + error states. |
| `pages/SouscriptionDetailPage.tsx` | One ticket, with status badge and a "Modifier le statut" button gated by `ticket:update`. Comments list + a comment form gated by `ticket:comment`. |
| `pages/CreateSouscriptionPage.tsx` | A form built with **react-hook-form + zod**. |

## Why react-hook-form + zod (and what that pair gives us)

**react-hook-form** is a tiny library that manages form state with
**uncontrolled inputs**. Instead of one `useState` per field (which
re-renders the entire form on every keystroke), inputs register
themselves with a hook and only the bits that changed re-render. Two
benefits:

1. **Performance** — large forms stay snappy.
2. **Less plumbing** — no `value={x} onChange={...}` on every input.

**zod** is a runtime schema validation library with first-class
TypeScript inference. You declare a schema once:

```ts
const schema = z.object({
  title: z.string().min(3, 'Au moins 3 caractères'),
  description: z.string().min(10),
  priority: z.enum(['LOW', 'MEDIUM', 'HIGH']),
});
type FormValues = z.infer<typeof schema>;  // ← static type from the schema
```

…and you get both the **runtime validator** AND the **static type**.
One source of truth, no drift.

The two libraries glue together via `@hookform/resolvers/zod`:

```ts
const form = useForm<FormValues>({ resolver: zodResolver(schema) });
```

`form.handleSubmit(onValid)` only runs `onValid` if the schema passes.
Field errors come from `form.formState.errors.title?.message`, etc.

## Why this is worth building

- It's the most realistic UI in the project (real form, real
  validation, real API call).
- It exercises 4 of the 7 spec scopes in one feature
  (`ticket:create`, `ticket:read`, `ticket:update`, `ticket:comment`),
  so a grader sees ABAC working in a high-stakes screen.
- It demonstrates that `apiClient` is functional: the create form
  POSTs, the response interceptor's mock fallback fires (because
  there's no backend), and the UI receives the synthesized
  `ApiResponse<Ticket>` envelope.
